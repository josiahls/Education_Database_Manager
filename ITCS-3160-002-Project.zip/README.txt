Project is created for ITCS 3160 - 002 Semester Project. 
Class took place Fall 2016, UNC Charlotte. 

Participants: Josiah Laivins, Andrew Schlesinger, Daniel Gehrin

Farther instructions can be found in ITCS-3160-002-Project pdf.  